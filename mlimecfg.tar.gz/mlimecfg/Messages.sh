#! /usr/bin/env bash
xgettext --from-code=GB18030 --keyword=i18n --keyword=ki18n --kde src/*.cpp -o po/kcm_mlimecfg.pot
